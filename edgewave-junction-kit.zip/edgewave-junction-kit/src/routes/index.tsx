import { createFileRoute } from "@tanstack/react-router";
import { lazy, Suspense, useEffect, useMemo, useRef, useState } from "react";
import { useHydrated } from "@tanstack/react-router";
import { RadioTower, Siren } from "lucide-react";

import { EventLog } from "@/components/EventLog";
import { SignalJunction } from "@/components/SignalJunction";
import {
  ambulanceEtaSec,
  DETECTION_RADIUS_M,
  initSim,
  lightsFor,
  makeEvent,
  PHASE_LABEL,
  phaseRemainingSec,
  schematicOffsetPx,
  SPAWN_DISTANCE_M,
  tickSim,
  triggerPreemption,
  type Axis,
  type LogEvent,
  type SimState,
} from "@/lib/signal-engine";

const JunctionMap = lazy(() => import("@/components/JunctionMap"));

// Demo junction: Park Street × Chowringhee area, Kolkata.
const JUNCTION = { lat: 22.5726, lng: 88.3639 };
const LAT_M = 111_320;
const metersToLat = (m: number) => m / LAT_M;
const metersToLng = (m: number, lat: number) => m / (LAT_M * Math.cos((lat * Math.PI) / 180));

const APPROACH_BY_AXIS: Record<Axis, { label: string; axis: Axis }> = {
  NS: { label: "North", axis: "NS" },
  EW: { label: "East", axis: "EW" },
};

const TICK_MS = 250;

function spawnForAxis(axis: Axis) {
  return axis === "NS"
    ? { lat: JUNCTION.lat + metersToLat(SPAWN_DISTANCE_M), lng: JUNCTION.lng }
    : { lat: JUNCTION.lat, lng: JUNCTION.lng + metersToLng(SPAWN_DISTANCE_M, JUNCTION.lat) };
}

function ambulancePos(axis: Axis, distanceM: number) {
  return axis === "NS"
    ? { lat: JUNCTION.lat + metersToLat(distanceM), lng: JUNCTION.lng }
    : { lat: JUNCTION.lat, lng: JUNCTION.lng + metersToLng(distanceM, JUNCTION.lat) };
}

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      {
        title: "EdgeWave Junction Kit — Traffic Signal Control Center",
      },
      {
        name: "description",
        content:
          "Live 4-way junction signal dashboard with emergency vehicle pre-emption: real-time map, dynamic red/yellow/green phases, and an auditable event log.",
      },
      { property: "og:title", content: "EdgeWave Junction Kit — Traffic Signal Control Center" },
      {
        property: "og:description",
        content:
          "Monitor a live junction on the map, watch North/South/East/West signals cycle, and fire emergency vehicle pre-emption with a full event log.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
});

function Index() {
  const [sim, setSim] = useState<SimState>(initSim);
  const [logs, setLogs] = useState<LogEvent[]>(() => [
    makeEvent("info", "EdgeWave Junction Kit online — normal cycle running at EdgeWave Junction"),
    makeEvent("info", "Detection geofence armed — radius 400m, Code 3 priority enabled"),
  ]);
  const [nextRunIdx, setNextRunIdx] = useState(0);
  const [clock, setClock] = useState<string | null>(null);
  const hydrated = useHydrated();
  const simRef = useRef(sim);
  simRef.current = sim;

  useEffect(() => {
    const timer = setInterval(() => {
      const { state, events } = tickSim(simRef.current, TICK_MS);
      simRef.current = state;
      setSim(state);
      if (events.length) {
        setLogs((prev) => [...events.reverse(), ...prev].slice(0, 80));
      }
    }, TICK_MS);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const update = () => setClock(`${new Date().toISOString().slice(11, 19)} UTC`);
    update();
    const timer = setInterval(update, 1000);
    return () => clearInterval(timer);
  }, []);

  const preempt = sim.preempt;
  const lights = lightsFor(sim.phase);
  const remaining = phaseRemainingSec(sim);
  const eta = ambulanceEtaSec(sim);

  const nextApproach = APPROACH_BY_AXIS[nextRunIdx % 2 === 0 ? "NS" : "EW"];

  const pushLogs = (events: LogEvent[]) => {
    if (events.length) setLogs((prev) => [...events.reverse(), ...prev].slice(0, 80));
  };

  const handlePreempt = () => {
    if (simRef.current.preempt) return;
    const approach = APPROACH_BY_AXIS[nextRunIdx % 2 === 0 ? "NS" : "EW"];
    const { state, events } = triggerPreemption(simRef.current, approach.axis, approach.label);
    simRef.current = state;
    setSim(state);
    pushLogs(events);
    setNextRunIdx((i) => i + 1);
  };

  const mapAmbulance = useMemo(() => {
    if (!preempt) return null;
    const pos = ambulancePos(preempt.axis, preempt.ambulance.distanceM);
    return { id: preempt.id, axis: preempt.axis, lat: pos.lat, lng: pos.lng };
  }, [preempt]);
  const mapSpawn = useMemo(() => (preempt ? spawnForAxis(preempt.axis) : null), [preempt?.id]);

  const schematicAmbulance = preempt
    ? { axis: preempt.axis, offsetPx: schematicOffsetPx(preempt.ambulance.distanceM) }
    : null;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="flex items-center justify-between border-b border-border px-5 py-3">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/15 text-primary">
            <RadioTower className="h-5 w-5" />
          </div>
          <div>
            <h1 className="font-display text-lg font-semibold leading-tight tracking-tight">
              EdgeWave Junction Kit
            </h1>
            <p className="text-[10px] font-medium uppercase tracking-[0.25em] text-muted-foreground">
              Traffic Signal Control Center
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {preempt ? (
            <span className="ewv-flash inline-flex items-center gap-2 rounded-full border border-emergency/40 bg-emergency/10 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-emergency">
              <Siren className="h-3.5 w-3.5" />
              Pre-emption active
            </span>
          ) : (
            <span className="inline-flex items-center gap-2 rounded-full border border-signal-green/40 bg-signal-green/10 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-signal-green">
              <span className="h-1.5 w-1.5 rounded-full bg-signal-green" />
              Normal cycle
            </span>
          )}
          <span className="hidden font-mono text-[11px] text-muted-foreground sm:inline" suppressHydrationWarning>
            {clock ?? "--:--:-- UTC"}
          </span>
        </div>
      </header>

      {/* Dashboard */}
      <main className="grid gap-4 p-4 lg:h-[calc(100vh-73px)] lg:grid-cols-5">
        {/* Live map */}
        <section className="flex min-h-[420px] flex-col overflow-hidden rounded-xl border border-border bg-card lg:col-span-3">
          <div className="flex items-center justify-between px-4 py-2.5">
            <h2 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
              Live Map — EdgeWave Junction
            </h2>
            <div className="flex items-center gap-3 font-mono text-[10px] text-muted-foreground">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-primary" /> junction
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-info" /> ambulance route
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-primary/40" /> detection {DETECTION_RADIUS_M}m
              </span>
            </div>
          </div>
          <div className="relative min-h-0 flex-1">
            {hydrated ? (
              <Suspense
                fallback={
                  <div className="flex h-full items-center justify-center bg-panel font-mono text-xs text-muted-foreground">
                    loading map…
                  </div>
                }
              >
                <JunctionMap
                  junction={JUNCTION}
                  radiusM={DETECTION_RADIUS_M}
                  ambulance={mapAmbulance}
                  spawn={mapSpawn}
                />
              </Suspense>
            ) : (
              <div className="flex h-full items-center justify-center bg-panel font-mono text-xs text-muted-foreground">
                loading map…
              </div>
            )}
            {preempt && (
              <div className="absolute left-3 top-3 rounded-lg border border-emergency/40 bg-background/85 px-3 py-2 font-mono text-[11px] text-emergency backdrop-blur">
                <span className="font-semibold">{preempt.id}</span> · {preempt.approachLabel} approach
                {eta !== null && <> · ETA {eta}s</>}
              </div>
            )}
          </div>
        </section>

        {/* Junction view + log */}
        <section className="flex min-h-0 flex-col gap-4 lg:col-span-2">
          <div className="rounded-xl border border-border bg-card">
            <div className="flex items-center justify-between px-4 py-2.5">
              <h2 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
                Junction Signal View
              </h2>
              <span className="rounded-md bg-muted px-2 py-1 font-mono text-[10px] uppercase tracking-wider text-muted-foreground">
                {preempt?.stage === "hold"
                  ? "GREEN HELD · EMERGENCY"
                  : `${PHASE_LABEL[sim.phase]} · ${remaining}s`}
              </span>
            </div>
            <div className="px-6 pb-4">
              <SignalJunction lights={lights} ambulance={schematicAmbulance} />
            </div>
            <div className="border-t border-border px-4 py-3">
              {preempt ? (
                <p className="mb-3 flex items-center gap-2 font-mono text-[11px] text-emergency">
                  <Siren className="h-3.5 w-3.5 shrink-0" />
                  {preempt.id} from {preempt.approachLabel} —{" "}
                  {preempt.stage === "hold" ? "green held" : "switching phase"}, ETA{" "}
                  {eta !== null ? `${eta}s` : "crossing"}
                </p>
              ) : (
                <p className="mb-3 font-mono text-[11px] text-muted-foreground">
                  Next phase change in {remaining}s
                </p>
              )}
              <button
                onClick={handlePreempt}
                disabled={Boolean(preempt)}
                className="flex w-full items-center justify-center gap-2.5 rounded-lg bg-primary px-4 py-3 text-sm font-semibold uppercase tracking-wider text-primary-foreground transition-all hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-45"
              >
                <Siren className="h-4.5 w-4.5" />
                {preempt ? "Pre-emption in progress…" : "Emergency Vehicle Preemption"}
              </button>
              <p className="mt-2 text-center font-mono text-[10px] text-muted-foreground">
                Next simulated run: ambulance from {nextApproach.label}
              </p>
            </div>
          </div>

          <div className="flex min-h-0 flex-1 flex-col rounded-xl border border-border bg-card">
            <div className="flex items-center justify-between px-4 py-2.5">
              <h2 className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
                Event Log
              </h2>
              <div className="flex gap-3 font-mono text-[10px] text-muted-foreground">
                <span>{sim.preemptCount} preemptions</span>
                <span className="text-signal-green">{Math.round(sim.timeSavedTotalSec)}s saved</span>
              </div>
            </div>
            <div className="ewv-scroll min-h-[180px] flex-1 overflow-y-auto px-4 pb-3 lg:min-h-0">
              <EventLog events={logs} />
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
