import { useEffect, useRef } from "react";
import * as maplibregl from "maplibre-gl";
// Vite resolves this to a URL the worker can be served from (maplibre-gl 6 under Vite).
import maplibreWorkerUrl from "maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url";
import "maplibre-gl/dist/maplibre-gl.css";

maplibregl.setWorkerUrl(maplibreWorkerUrl);

export interface MapAmbulance {
  id: string;
  axis: "NS" | "EW";
  lat: number;
  lng: number;
}

interface JunctionMapProps {
  junction: { lat: number; lng: number };
  radiusM: number;
  ambulance: MapAmbulance | null;
  spawn: { lat: number; lng: number } | null;
}

const LAT_M = 111_320;
const metersToLat = (m: number) => m / LAT_M;
const metersToLng = (m: number, lat: number) => m / (LAT_M * Math.cos((lat * Math.PI) / 180));
const PAST_METRES = 170;

function circleRing(center: { lat: number; lng: number }, radiusM: number, steps = 72) {
  return Array.from({ length: steps + 1 }, (_, i) => {
    const a = (i / steps) * Math.PI * 2;
    return [
      center.lng + metersToLng(radiusM * Math.cos(a), center.lat),
      center.lat + metersToLat(radiusM * Math.sin(a)),
    ] as [number, number];
  });
}

function ambulanceElement() {
  const el = document.createElement("div");
  el.className = "ewv-amb-marker";
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("width", "14");
  svg.setAttribute("height", "14");
  svg.innerHTML =
    '<path d="M3 7h11v8H3z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M14 10h3.5L20 12.5V15h-6" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="7" cy="17.5" r="1.6" fill="currentColor"/><circle cx="16.5" cy="17.5" r="1.6" fill="currentColor"/>';
  const body = document.createElement("span");
  body.className = "ewv-amb-body";
  body.appendChild(svg);
  const pulse = document.createElement("span");
  pulse.className = "ewv-amb-pulse";
  el.appendChild(pulse);
  el.appendChild(body);
  return el;
}

function routeLine(spawn: { lat: number; lng: number }, junction: { lat: number; lng: number }, axis: "NS" | "EW") {
  const end =
    axis === "NS"
      ? [junction.lng, junction.lat - metersToLat(PAST_METRES)]
      : [junction.lng - metersToLng(PAST_METRES, junction.lat), junction.lat];
  return {
    type: "Feature" as const,
    properties: {},
    geometry: {
      type: "LineString" as const,
      coordinates: [
        [spawn.lng, spawn.lat],
        [junction.lng, junction.lat],
        end,
      ],
    },
  };
}

export default function JunctionMap({ junction, radiusM, ambulance, spawn }: JunctionMapProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const ambMarkerRef = useRef<maplibregl.Marker | null>(null);
  const routeKeyRef = useRef<string | null>(null);
  const loadedRef = useRef(false);

  useEffect(() => {
    const container = containerRef.current;
    if (!container || mapRef.current) return;

    const map = new maplibregl.Map({
      container,
      style: "https://tiles.openfreemap.org/styles/dark",
      center: [junction.lng, junction.lat],
      zoom: 16.3,
      attributionControl: { compact: false },
    });
    map.addControl(new maplibregl.NavigationControl({ showCompass: false }), "bottom-right");
    mapRef.current = map;

    map.on("load", () => {
      loadedRef.current = true;

      map.addSource("geofence", {
        type: "geojson",
        data: {
          type: "Feature",
          properties: {},
          geometry: { type: "Polygon", coordinates: [circleRing(junction, radiusM)] },
        },
      });
      map.addLayer({
        id: "geofence-fill",
        type: "fill",
        source: "geofence",
        paint: { "fill-color": "#f59e0b", "fill-opacity": 0.07 },
      });
      map.addLayer({
        id: "geofence-line",
        type: "line",
        source: "geofence",
        paint: {
          "line-color": "#f59e0b",
          "line-opacity": 0.45,
          "line-width": 1.4,
          "line-dasharray": [2, 2],
        },
      });

      map.addSource("route", {
        type: "geojson",
        data: { type: "Feature", properties: {}, geometry: { type: "LineString", coordinates: [] } },
      });
      map.addLayer({
        id: "route-line",
        type: "line",
        source: "route",
        layout: { "line-cap": "round", "line-join": "round" },
        paint: {
          "line-color": "#22d3ee",
          "line-width": 2.5,
          "line-opacity": 0.85,
          "line-dasharray": [0.5, 1.6],
        },
      });

      map.addSource("junction-pt", {
        type: "geojson",
        data: {
          type: "Feature",
          properties: {},
          geometry: { type: "Point", coordinates: [junction.lng, junction.lat] },
        },
      });
      map.addLayer({
        id: "junction-dot",
        type: "circle",
        source: "junction-pt",
        paint: {
          "circle-radius": 6,
          "circle-color": "#f59e0b",
          "circle-stroke-color": "#fde68a",
          "circle-stroke-width": 2,
        },
      });
    });

    return () => {
      map.remove();
      mapRef.current = null;
      ambMarkerRef.current = null;
      loadedRef.current = false;
      routeKeyRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Live ambulance movement + route overlay.
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !loadedRef.current) return;

    const routeKey = ambulance && spawn ? `${ambulance.axis}:${spawn.lat.toFixed(6)},${spawn.lng.toFixed(6)}` : null;
    if (routeKey !== routeKeyRef.current) {
      routeKeyRef.current = routeKey;
      const src = map.getSource("route") as maplibregl.GeoJSONSource | undefined;
      if (src) {
        src.setData(
          ambulance && spawn
            ? routeLine(spawn, junction, ambulance.axis)
            : { type: "Feature", properties: {}, geometry: { type: "LineString", coordinates: [] } },
        );
      }
    }

    if (ambulance) {
      if (!ambMarkerRef.current) {
        ambMarkerRef.current = new maplibregl.Marker({ element: ambulanceElement() })
          .setLngLat([ambulance.lng, ambulance.lat])
          .addTo(map);
      } else {
        ambMarkerRef.current.setLngLat([ambulance.lng, ambulance.lat]);
      }
    } else if (ambMarkerRef.current) {
      ambMarkerRef.current.remove();
      ambMarkerRef.current = null;
    }
  }, [ambulance, spawn, junction.lng, junction.lat]);

  return <div ref={containerRef} className="h-full w-full" />;
}
