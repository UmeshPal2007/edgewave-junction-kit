import type { Axis, Direction, LightColor } from "@/lib/signal-engine";

interface SignalJunctionProps {
  lights: Record<Direction, LightColor>;
  ambulance: { axis: Axis; offsetPx: number } | null;
}

const HEADS: { dir: Direction; x: number; y: number }[] = [
  { dir: "N", x: 226, y: 98 },
  { dir: "E", x: 226, y: 226 },
  { dir: "S", x: 112, y: 226 },
  { dir: "W", x: 112, y: 98 },
];

const LAMPS: { color: LightColor; cy: number }[] = [
  { color: "red", cy: 15 },
  { color: "yellow", cy: 30 },
  { color: "green", cy: 45 },
];

const COLOR_VAR: Record<LightColor, string> = {
  red: "var(--signal-red)",
  yellow: "var(--signal-yellow)",
  green: "var(--signal-green)",
};

function SignalHead({ x, y, state }: { x: number; y: number; state: LightColor }) {
  return (
    <g>
      <rect x={x} y={y} width="22" height="60" rx="7" fill="var(--signal-head)" stroke="var(--border)" />
      {LAMPS.map(({ color, cy }) => {
        const lit = color === state;
        return (
          <circle
            key={color}
            cx={x + 11}
            cy={y + cy}
            r="6.5"
            fill={lit ? COLOR_VAR[color] : "var(--signal-off)"}
            style={lit ? { filter: `drop-shadow(0 0 6px ${COLOR_VAR[color]})` } : undefined}
          />
        );
      })}
    </g>
  );
}

const LABEL_POS: Record<Direction, { x: number; y: number }> = {
  N: { x: 180, y: 22 },
  S: { x: 180, y: 344 },
  E: { x: 340, y: 184 },
  W: { x: 20, y: 184 },
};

export function SignalJunction({ lights, ambulance }: SignalJunctionProps) {
  return (
    <svg viewBox="0 0 360 360" className="h-auto w-full" role="img" aria-label="Four-way junction signal view">
      {/* ground */}
      <rect width="360" height="360" fill="var(--panel)" />
      {/* emergency approach glow */}
      {ambulance && (
        <rect
          x={ambulance.axis === "NS" ? 140 : 0}
          y={ambulance.axis === "NS" ? 0 : 140}
          width={ambulance.axis === "NS" ? 80 : 360}
          height={ambulance.axis === "NS" ? 360 : 80}
          fill="var(--emergency)"
          opacity="0.1"
        />
      )}
      {/* roads */}
      <rect x="140" y="0" width="80" height="360" fill="var(--asphalt)" />
      <rect x="0" y="140" width="360" height="80" fill="var(--asphalt)" />
      {/* centre lane dashes */}
      {[
        { x1: 180, y1: 6, x2: 180, y2: 140 },
        { x1: 180, y1: 220, x2: 180, y2: 354 },
        { x1: 6, y1: 180, x2: 140, y2: 180 },
        { x1: 220, y1: 180, x2: 354, y2: 180 },
      ].map((l, i) => (
        <line key={i} {...l} stroke="var(--junction-line)" strokeWidth="2" strokeDasharray="10 10" opacity="0.7" />
      ))}
      {/* stop lines */}
      <rect x="150" y="133" width="60" height="4" fill="var(--foreground)" opacity="0.5" />
      <rect x="150" y="223" width="60" height="4" fill="var(--foreground)" opacity="0.5" />
      <rect x="133" y="150" width="4" height="60" fill="var(--foreground)" opacity="0.5" />
      <rect x="223" y="150" width="4" height="60" fill="var(--foreground)" opacity="0.5" />
      {/* signal heads */}
      {HEADS.map((h) => (
        <SignalHead key={h.dir} x={h.x} y={h.y} state={lights[h.dir]} />
      ))}
      {/* direction labels */}
      {(Object.keys(LABEL_POS) as Direction[]).map((d) => (
        <text
          key={d}
          x={LABEL_POS[d].x}
          y={LABEL_POS[d].y}
          textAnchor="middle"
          fill="var(--muted-foreground)"
          style={{ font: "600 12px var(--font-mono)", letterSpacing: "0.1em" }}
        >
          {d}
        </text>
      ))}
      {/* simulated ambulance */}
      {ambulance && (
        <g
          transform={
            ambulance.axis === "NS"
              ? `translate(180 ${180 - ambulance.offsetPx})`
              : `translate(${180 + ambulance.offsetPx} 180)`
          }
        >
          <circle r="17" fill="var(--emergency)" opacity="0.18" className="ewv-schematic-pulse" />
          <circle r="11" fill="var(--card)" stroke="var(--emergency)" strokeWidth="2" />
          <text textAnchor="middle" dominantBaseline="central" fontSize="12">
            🚑
          </text>
        </g>
      )}
    </svg>
  );
}
