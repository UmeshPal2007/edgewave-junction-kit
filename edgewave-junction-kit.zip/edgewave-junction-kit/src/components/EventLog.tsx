import type { LogLevel, LogEvent } from "@/lib/signal-engine";

const LEVEL_STYLE: Record<LogLevel, { dot: string; text: string }> = {
  info: { dot: "bg-info", text: "text-muted-foreground" },
  success: { dot: "bg-signal-green", text: "text-foreground" },
  warning: { dot: "bg-signal-yellow", text: "text-signal-yellow" },
  alert: { dot: "bg-emergency", text: "text-emergency" },
};

function fmtTime(ts: number): string {
  return new Date(ts).toLocaleTimeString("en-GB", { hour12: false });
}

export function EventLog({ events }: { events: LogEvent[] }) {
  return (
    <div className="flex flex-col gap-1.5 overflow-y-auto pr-1 font-mono text-[11px] leading-relaxed">
      {events.map((e) => {
        const style = LEVEL_STYLE[e.level];
        return (
          <div key={e.id} className="flex items-start gap-2">
            <span className="shrink-0 text-muted-foreground/60" suppressHydrationWarning>
              {fmtTime(e.ts)}
            </span>
            <span className={`mt-[5px] h-1.5 w-1.5 shrink-0 rounded-full ${style.dot}`} />
            <span className={style.text}>{e.message}</span>
          </div>
        );
      })}
    </div>
  );
}
