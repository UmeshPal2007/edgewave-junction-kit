// EdgeWave Junction Kit — signal control engine (pure, isomorphic logic).
// Implements the intersection phase cycle plus emergency pre-emption overlay.

export type Axis = "NS" | "EW";
export type Direction = "N" | "S" | "E" | "W";
export type LightColor = "red" | "yellow" | "green";

export type PhaseId =
  | "NS_GREEN"
  | "NS_YELLOW"
  | "ALL_RED_A"
  | "EW_GREEN"
  | "EW_YELLOW"
  | "ALL_RED_B";

export type LogLevel = "info" | "success" | "warning" | "alert";

export interface LogEvent {
  id: string;
  ts: number;
  level: LogLevel;
  message: string;
}

export interface Ambulance {
  id: string;
  approachLabel: string;
  axis: Axis;
  /** Signed metres from junction centre: >0 approaching, <0 past the box. */
  distanceM: number;
  speedMps: number;
  passed: boolean;
}

export interface Preemption {
  id: string;
  axis: Axis;
  approachLabel: string;
  stage: "transition" | "hold";
  ambulance: Ambulance;
  etaSec: number;
  timeSavedSec: number;
}

export interface SimState {
  phase: PhaseId;
  elapsedMs: number;
  preempt: Preemption | null;
  preemptCount: number;
  timeSavedTotalSec: number;
}

// ---- Timing plan -----------------------------------------------------------

const GREEN_MS = 10_000;
const YELLOW_MS = 3_000;
const ALL_RED_MS = 2_000;
// Safe-but-fast transition while an emergency vehicle is inbound.
const PRE_YELLOW_MS = 1_200;
const PRE_ALL_RED_MS = 1_000;

const PHASE_DURATION: Record<PhaseId, number> = {
  NS_GREEN: GREEN_MS,
  NS_YELLOW: YELLOW_MS,
  ALL_RED_A: ALL_RED_MS,
  EW_GREEN: GREEN_MS,
  EW_YELLOW: YELLOW_MS,
  ALL_RED_B: ALL_RED_MS,
};

const NEXT_PHASE: Record<PhaseId, PhaseId> = {
  NS_GREEN: "NS_YELLOW",
  NS_YELLOW: "ALL_RED_A",
  ALL_RED_A: "EW_GREEN",
  EW_GREEN: "EW_YELLOW",
  EW_YELLOW: "ALL_RED_B",
  ALL_RED_B: "NS_GREEN",
};

const AXIS_PHASES = {
  NS: { green: "NS_GREEN", yellow: "NS_YELLOW", allRedBefore: "ALL_RED_A", opposite: "EW" },
  EW: { green: "EW_GREEN", yellow: "EW_YELLOW", allRedBefore: "ALL_RED_B", opposite: "NS" },
} as const satisfies Record<Axis, { green: PhaseId; yellow: PhaseId; allRedBefore: PhaseId; opposite: Axis }>;

export const PHASE_LABEL: Record<PhaseId, string> = {
  NS_GREEN: "North–South Green",
  NS_YELLOW: "North–South Yellow",
  ALL_RED_A: "All-Red Clearance",
  EW_GREEN: "East–West Green",
  EW_YELLOW: "East–West Yellow",
  ALL_RED_B: "All-Red Clearance",
};

export const DETECTION_RADIUS_M = 400;
const SPAWN_M = 380;
const SPEED_MPS = 30; // ~108 km/h emergency run
const CLEAR_M = -150; // considered clear once this far past the junction

let logSeq = 0;

export function makeEvent(level: LogLevel, message: string): LogEvent {
  return { id: `evt-${Date.now()}-${logSeq++}`, ts: Date.now(), level, message };
}

export function initSim(): SimState {
  return { phase: "NS_GREEN", elapsedMs: 0, preempt: null, preemptCount: 0, timeSavedTotalSec: 0 };
}

export function lightsFor(phase: PhaseId): Record<Direction, LightColor> {
  const ns: LightColor =
    phase === "NS_GREEN" ? "green" : phase === "NS_YELLOW" ? "yellow" : "red";
  const ew: LightColor =
    phase === "EW_GREEN" ? "green" : phase === "EW_YELLOW" ? "yellow" : "red";
  return { N: ns, S: ns, E: ew, W: ew };
}

/** Seconds the ambulance would wait at red under the normal fixed plan. */
function estimateWaitSec(phase: PhaseId, elapsedMs: number, etaSec: number, axis: Axis): number {
  const g = AXIS_PHASES[axis].green;
  let t = -elapsedMs / 1000;
  let p: PhaseId = phase;
  const intervals: { s: number; e: number }[] = [];
  for (let i = 0; i < 16; i++) {
    const d = PHASE_DURATION[p] / 1000;
    if (p === g) intervals.push({ s: t, e: t + d });
    t += d;
    p = NEXT_PHASE[p];
  }
  for (const { s, e } of intervals) if (etaSec >= s && etaSec <= e) return 0;
  const next = intervals.find(({ s }) => s > etaSec);
  return next ? Math.max(0, Math.round(next.s - etaSec)) : 0;
}

export function triggerPreemption(
  prev: SimState,
  axis: Axis,
  approachLabel: string,
): { state: SimState; events: LogEvent[] } {
  if (prev.preempt) return { state: prev, events: [] };

  const events: LogEvent[] = [];
  const count = prev.preemptCount + 1;
  const id = `AMB-${String(count).padStart(2, "0")}`;
  const ambulance: Ambulance = {
    id,
    approachLabel,
    axis,
    distanceM: SPAWN_M,
    speedMps: SPEED_MPS,
    passed: false,
  };
  const etaSec = Math.round(SPAWN_M / SPEED_MPS);
  const timeSavedSec = estimateWaitSec(prev.phase, prev.elapsedMs, etaSec, axis);

  events.push(
    makeEvent(
      "alert",
      `${id} detected approaching from ${approachLabel} — ${SPAWN_M}m out, ETA ${etaSec}s (Code 3)`,
    ),
  );
  events.push(makeEvent("info", `Pre-emption requested for ${approachLabel} approach`));

  const tp = AXIS_PHASES[axis];
  const op = AXIS_PHASES[tp.opposite];
  let phase: PhaseId = prev.phase;
  let elapsedMs = prev.elapsedMs;

  if (phase === tp.green) {
    events.push(makeEvent("success", `${approachLabel} already green — extending for ${id}`));
  } else if (phase === tp.yellow) {
    events.push(makeEvent("info", `${approachLabel} yellow in progress — shortening clearance`));
  } else if (phase === "ALL_RED_A" || phase === "ALL_RED_B") {
    phase = tp.allRedBefore;
    elapsedMs = ALL_RED_MS - PRE_ALL_RED_MS;
    events.push(makeEvent("info", "Cross traffic locked out — all-red clearance"));
  } else if (phase === op.green) {
    phase = op.yellow;
    elapsedMs = YELLOW_MS - PRE_YELLOW_MS;
    events.push(
      makeEvent(
        "warning",
        `Switching priority to ${approachLabel} — cross traffic ramping down (yellow)`,
      ),
    );
  } else {
    elapsedMs = Math.max(elapsedMs, YELLOW_MS - PRE_YELLOW_MS);
    events.push(makeEvent("warning", `Priority override — cross traffic yellow`));
  }

  const preempt: Preemption = {
    id,
    axis,
    approachLabel,
    stage: phase === tp.green ? "hold" : "transition",
    ambulance,
    etaSec,
    timeSavedSec,
  };

  return {
    state: { ...prev, phase, elapsedMs, preempt, preemptCount: count },
    events,
  };
}

export function tickSim(
  prev: SimState,
  dtMs: number,
): { state: SimState; events: LogEvent[] } {
  const events: LogEvent[] = [];
  let { phase, elapsedMs, preempt, preemptCount, timeSavedTotalSec } = prev;
  elapsedMs += dtMs;

  if (preempt) {
    const amb = {
      ...preempt.ambulance,
      distanceM: preempt.ambulance.distanceM - (preempt.ambulance.speedMps * dtMs) / 1000,
    };
    if (!amb.passed && amb.distanceM <= 0) {
      amb.passed = true;
      events.push(makeEvent("success", `${amb.id} crossing the junction — green held`));
    }
    if (amb.distanceM <= CLEAR_M) {
      events.push(makeEvent("success", `${amb.id} cleared the junction — releasing priority`));
      if (preempt.timeSavedSec > 0) {
        events.push(
          makeEvent("info", `Est. ${preempt.timeSavedSec}s of red-light wait saved for ${amb.id}`),
        );
      }
      timeSavedTotalSec += preempt.timeSavedSec;
      preempt = null;
      // Hand back to the normal plan via the cleared axis' yellow.
      phase = AXIS_PHASES[amb.axis].yellow;
      elapsedMs = 0;
    } else {
      preempt = { ...preempt, ambulance: amb };
    }
  }

  const tp = preempt ? AXIS_PHASES[preempt.axis] : null;

  if (preempt && preempt.stage === "hold") {
    // Emergency green: hold until clearance (handled above).
  } else if (preempt && preempt.stage === "transition" && tp) {
    const op = AXIS_PHASES[tp.opposite];
    if (elapsedMs >= PHASE_DURATION[phase]) {
      if (phase === op.yellow) {
        phase = tp.allRedBefore;
        elapsedMs = ALL_RED_MS - PRE_ALL_RED_MS;
        events.push(makeEvent("info", "All-red clearance interval"));
      } else if (phase === tp.yellow) {
        phase = tp.allRedBefore;
        elapsedMs = ALL_RED_MS - PRE_ALL_RED_MS;
        events.push(makeEvent("info", "All-red clearance interval"));
      } else if (phase === tp.allRedBefore) {
        phase = tp.green;
        elapsedMs = 0;
        const liveEta = Math.max(
          0,
          Math.round(preempt.ambulance.distanceM / preempt.ambulance.speedMps),
        );
        preempt = { ...preempt, stage: "hold" };
        events.push(
          makeEvent(
            "success",
            `GREEN granted for ${preempt.approachLabel} approach — ${preempt.id} ETA ${liveEta}s`,
          ),
        );
      }
      // Defensive: never skip straight into an unserved green.
    }
  } else {
    const dur = PHASE_DURATION[phase];
    if (elapsedMs >= dur) {
      elapsedMs -= dur;
      phase = NEXT_PHASE[phase];
    }
  }

  return { state: { phase, elapsedMs, preempt, preemptCount, timeSavedTotalSec }, events };
}

export function phaseRemainingSec(state: SimState): number {
  return Math.max(0, Math.ceil((PHASE_DURATION[state.phase] - state.elapsedMs) / 1000));
}

export function ambulanceEtaSec(state: SimState): number | null {
  if (!state.preempt || state.preempt.ambulance.passed) return null;
  return Math.max(0, Math.ceil(state.preempt.ambulance.distanceM / state.preempt.ambulance.speedMps));
}

/** Position of the ambulance on the schematic, in px offset from centre along its axis. */
export function schematicOffsetPx(distanceM: number): number {
  return Math.max(-140, Math.min(SPAWN_M, distanceM)) * 0.36;
}

export const SPAWN_DISTANCE_M = SPAWN_M;
