import { describe, expect, it } from "vitest";
import {
  initSim,
  lightsFor,
  makeEvent,
  tickSim,
  triggerPreemption,
  type PhaseId,
} from "@/lib/signal-engine";

const DT = 250;

/** Advance the simulation for a wall-clock duration, collecting events. */
function run(state: ReturnType<typeof initSim>, ms: number) {
  const events = [];
  for (let t = 0; t < ms; t += DT) {
    const r = tickSim(state, DT);
    state = r.state;
    events.push(...r.events);
  }
  return { state, events };
}

describe("signal engine — normal cycle", () => {
  it("never shows conflicting greens and cycles all four approaches", () => {
    let state = initSim();
    const seen = new Set<string>();
    for (let t = 0; t < 40_000; t += DT) {
      const { state: next } = tickSim(state, DT);
      state = next;
      const lights = lightsFor(state.phase);
      // Safety: no opposing greens at any instant
      expect(lights.N === "green" && lights.E === "green").toBe(false);
      seen.add(state.phase);
    }
    expect(seen.has("NS_GREEN")).toBe(true);
    expect(seen.has("EW_GREEN")).toBe(true);
    expect(seen.has("NS_YELLOW")).toBe(true);
    expect(seen.has("ALL_RED_A")).toBe(true);
  });
});

describe("signal engine — emergency pre-emption", () => {
  it("grants green to the ambulance approach and logs the event", () => {
    let state = initSim();
    // Force the cross traffic green so pre-emption must run a transition.
    state = { ...state, phase: "EW_GREEN" as PhaseId, elapsedMs: 0 };

    const trigger = triggerPreemption(state, "NS", "North");
    state = trigger.state;
    expect(trigger.events.some((e) => e.level === "alert")).toBe(true);

    // Transition is fast and safe: yellow -> all-red -> NS green.
    const { state: after, events } = run(state, 5_000);
    expect(after.phase).toBe("NS_GREEN");
    expect(after.preempt?.stage).toBe("hold");
    expect(lightsFor(after.phase).N).toBe("green");
    expect(lightsFor(after.phase).S).toBe("green");
    expect(lightsFor(after.phase).E).toBe("red");
    expect(lightsFor(after.phase).W).toBe("red");

    const granted = events.find((e) => e.message.startsWith("GREEN granted for North"));
    expect(granted).toBeDefined();
  });

  it("releases priority after the ambulance clears and logs the whole run", () => {
    let state = initSim();
    state = { ...state, phase: "NS_GREEN" as PhaseId, elapsedMs: 0 };

    const trigger = triggerPreemption(state, "EW", "East");
    state = trigger.state;

    // Ambulance travels 380m approach + 150m clearance at 30 m/s -> ~17.7s.
    const { state: after, events } = run(state, 30_000);
    expect(after.preempt).toBeNull();
    expect(state.preemptCount).toBe(1);

    const messages = events.map((e) => e.message);
    expect(messages.some((m) => m.startsWith("GREEN granted for East"))).toBe(true);
    expect(messages.some((m) => m.includes("crossing the junction"))).toBe(true);
    expect(messages.some((m) => m.includes("cleared the junction"))).toBe(true);
  });

  it("extends green instead of switching when the approach is already green", () => {
    let state = initSim();
    state = { ...state, phase: "NS_GREEN" as PhaseId, elapsedMs: 0 };
    const trigger = triggerPreemption(state, "NS", "North");
    expect(trigger.state.preempt?.stage).toBe("hold");
    expect(trigger.state.phase).toBe("NS_GREEN");
    expect(trigger.events.some((e) => e.message.includes("already green"))).toBe(true);
  });

  it("estimates red-light wait saved for the ambulance", () => {
    let state = initSim();
    state = { ...state, phase: "NS_GREEN" as PhaseId, elapsedMs: 0 };
    const trigger = triggerPreemption(state, "EW", "East");
    // NS green just started; EW green starts ~15s later; ambulance ETA ~13s.
    expect(trigger.state.preempt?.timeSavedSec).toBeGreaterThan(0);
    expect(makeEvent("info", "x").ts).toBeGreaterThan(0);
  });
});
