<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

# Architecture rules

- The junction simulation is client-side only: `src/lib/signal-engine.ts` holds the pure phase/pre-emption state machine, ticked every 250ms from `src/routes/index.tsx`. No backend, no persistence — this is a self-contained demo. Keep engine logic pure and covered by `src/test/signal-engine.test.ts` (safety rule: conflicting greens must never display).
- The live map is MapLibre GL on the keyless OpenFreeMap dark style, loaded as a `React.lazy` module rendered inside `ClientOnly`-equivalent hydration gating (`useHydrated`) — never import `JunctionMap.tsx` statically from an SSR route.
